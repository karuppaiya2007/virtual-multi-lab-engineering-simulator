# Virtual Multi-Lab Engineering Simulator

A local-first educational engineering simulator built with React, TypeScript, Vite, Express and SQLite.

## Requirements
- Node.js 20 or newer (LTS recommended)
- npm

## Run in VS Code
1. Extract this project ZIP to a folder.
2. Open the extracted `virtual-multi-lab-engineering-simulator` folder in VS Code.
3. Open **Terminal → New Terminal**.
4. Install packages:
   ```bash
   npm install
   ```
5. Start the frontend and API together:
   ```bash
   npm run dev
   ```
6. Open **http://localhost:5173** in your browser. API health check: **http://localhost:4000/api/health**.

If SQLite's native dependency fails to install, use a current Node.js LTS release and rerun `npm install`. On Windows, ensure build tools are available if npm requests them.

## Implemented
- Dashboard and searchable lab directory with 22 lab/workspace categories.
- Separate lab-detail pages and categorized experiment lists.
- Educational calculation models for Ohm's law, series/parallel resistors, a simplified LED model, RC charging, AND/OR/XOR truth tables, signal generation, AM, sampling, and first-order response.
- Data-driven waveform plots with Recharts.
- Component reference library with descriptions, terminal details and example values.
- MATLAB-style / Scilab-style safe sample workspaces (restricted examples, not arbitrary code execution).
- Save/load circuit configuration, progress tracking and notes via Express API + SQLite; browser fallback for saved circuits/progress when the API is unavailable.
- Responsive layout and local development instructions.

## Important scope notes
This is a demonstrable educational MVP, not a full SPICE engine. The circuit illustration is a schematic preview, not a drag-and-drop breadboard editor with electrical net solving. Advanced transistor, VLSI, microwave, antenna, optical, microcontroller and advanced control experiments are catalogued as guided educational topics, but do not all have dedicated physics-accurate simulation models yet. MATLAB/Scilab workspaces support only the documented sample commands and do not execute arbitrary code. There is no authentication or cloud deployment configured.

## Useful commands
- `npm run dev` — run frontend and backend together
- `npm run build` — type-check and build frontend
- `npm run start` — start backend API only
- `npm run client` — frontend only
- `npm run server` — backend watch mode only

SQLite data is created automatically at `backend/data/simulator.sqlite`.
