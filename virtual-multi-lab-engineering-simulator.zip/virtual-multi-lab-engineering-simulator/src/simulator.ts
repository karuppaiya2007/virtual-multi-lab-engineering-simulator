export type Result={title:string;summary:string;metrics:{label:string;value:string}[];formula:string;points:{t:number;input:number;output:number}[];warnings:string[]};
export function simulate(kind:string,p:Record<string,number>):Result{
 const V=p.voltage??5,R=Math.max(0.001,p.resistance??1000),R2=Math.max(.001,p.resistance2??2200),C=Math.max(0.000000001,p.capacitance??0.0001),f=Math.max(0,p.frequency??1000),amp=p.amplitude??1;
 const warnings:string[]=[]; let metrics:{label:string;value:string}[]=[],points:{t:number;input:number;output:number}[]=[],formula='',summary='',title='';
 if(kind==='ohm'||kind==='series'||kind==='parallel'||kind==='led'){
   title=kind==='ohm'?'Ohm’s law':kind==='series'?'Series resistor network':kind==='parallel'?'Parallel resistor network':'LED educational model';
   const req=kind==='series'?R+R2:kind==='parallel'?(R*R2)/(R+R2):R;
   const drop=kind==='led'?Math.min(V,2):0, current=Math.max(0,(V-drop)/req),out=kind==='led'?Math.max(0,V-2):V;
   metrics=[{label:'Supply voltage',value:`${V.toFixed(2)} V`},{label:'Equivalent resistance',value:`${req.toFixed(2)} Ω`},{label:'Circuit current',value:`${(current*1000).toFixed(3)} mA`},{label:'Output / resistor voltage',value:`${out.toFixed(2)} V`}];
   formula=kind==='parallel'?'Req = (R₁ × R₂) / (R₁ + R₂)':kind==='series'?'Req = R₁ + R₂':'I = V / R';summary='Calculated using the configured educational DC circuit model.';
   if(kind==='led'&&V<=2)warnings.push('Supply is at or below the nominal LED forward voltage; the model predicts no forward current.');
   points=Array.from({length:21},(_,i)=>({t:i,input:V*i/20,output:V*i/20}));
 } else if(kind==='rc'){
   title='RC charging and discharging';const tau=R*C;metrics=[{label:'Resistance',value:`${R.toFixed(0)} Ω`},{label:'Capacitance',value:`${(C*1e6).toFixed(2)} µF`},{label:'Time constant τ',value:`${tau.toFixed(4)} s`},{label:'Final voltage',value:`${V.toFixed(2)} V`}];formula='Vc(t) = V × (1 − e^(−t/RC))';summary='Capacitor charging curve from the first-order RC model.';points=Array.from({length:81},(_,i)=>{const t=5*tau*i/80;return {t,input:V,output:V*(1-Math.exp(-t/tau))};});
 } else if(kind==='logic'){
   title='Digital logic truth table';const gate=p.gate??0;const rows=[0,1,2,3].map(n=>{const a=(n>>1)&1,b=n&1;let y=gate===1?(a|b):gate===2?(a^b):(a&b);return {t:n,input:a*2+b,output:y};});metrics=[{label:'Gate',value:gate===1?'OR':gate===2?'XOR':'AND'},{label:'Truth table rows',value:'4'},{label:'Output for A=1, B=1',value:String(rows[3].output)}];formula=gate===1?'Y = A OR B':gate===2?'Y = A XOR B':'Y = A AND B';summary='Truth table generated from the selected two-input logic function.';points=rows;
 } else if(kind==='signal'||kind==='am'||kind==='sampling'){
   title=kind==='am'?'Amplitude modulation':kind==='sampling'?'Sampling demonstration':'Signal generator';const fs=200,fc=f||10;metrics=[{label:'Signal amplitude',value:`${amp.toFixed(2)} V`},{label:'Frequency',value:`${fc.toFixed(2)} Hz`},{label:'Sample points',value:'201'},{label:'Model',value:kind==='am'?'AM educational model':kind==='sampling'?'Sample-and-hold model':'Sine wave'}];formula=kind==='am'?'s(t) = Ac[1 + m cos(2πfmt)] cos(2πfct)':kind==='sampling'?'x[n] = A sin(2π f n / fs)':'x(t) = A sin(2πft)';summary='Waveform points are generated from the selected mathematical model.';points=Array.from({length:201},(_,i)=>{const t=i/fs;const m=Math.sin(2*Math.PI*2*t);const carrier=Math.sin(2*Math.PI*fc*t);return {t,input:amp*m,output:kind==='am'?amp*(1+.7*m)*carrier:kind==='sampling'?(i%4===0?amp*m:0):amp*carrier};});
 } else {
   title='First-order step response';const tau=Math.max(.01,p.tau??1);metrics=[{label:'Time constant',value:`${tau.toFixed(2)} s`},{label:'Final value',value:`${V.toFixed(2)}`},{label:'Rise at 1τ',value:'63.2%'},{label:'Model',value:'First-order system'}];formula='y(t) = K(1 − e^(−t/τ))';summary='Normalized first-order step response; educational model.';points=Array.from({length:81},(_,i)=>{const t=5*tau*i/80;return {t,input:V,output:V*(1-Math.exp(-t/tau))};});
 }
 return {title,summary,metrics,formula,points,warnings};
}
